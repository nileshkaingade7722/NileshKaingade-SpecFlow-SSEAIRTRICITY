﻿using System;
using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace specflow.Features
{
    [Binding]
    public class AsAResidentFromCountrySteps
    {
        static DriverFactory driverFactory = new DriverFactory();
        static IWebDriver driver = driverFactory.getDriver();
        CompareApplianciesHomePage compareApplianciesHomePage = new CompareApplianciesHomePage(driver);

        [BeforeScenario]
        public void launchBrowser()
        {
            compareApplianciesHomePage.goTo();
            Console.WriteLine("Opened URL");
        }

        [Given(@"I am on citizen advice site and resident from '(.*)'")]
        public void GivenIAmOnCitizenAdviceSiteAndResidentFrom(string resident_country)
        {
            compareApplianciesHomePage.verifyCitizenAdvicePage();
        }
        
        [When(@"I select this applies to '(.*)'")]
        public void WhenISelectThisAppliesTo(string select_applies)
        {
            compareApplianciesHomePage.selectAdviceResidentFrom();
            compareApplianciesHomePage.selectResidentFromValue(select_applies);
        }
        
        [When(@"I add the ""(.*)"" to compare your list")]
        public void WhenIAddTheToCompareYourList(string appappliancesName)
        {
            compareApplianciesHomePage.addListOfAppliance(appappliancesName);
        }

        [When(@"I enter the ""(.*)"" for the appliencies")]
        public void WhenIEnterTheForTheAppliencies(string addAverageAppliance)
        {
            compareApplianciesHomePage.enterAverageHours(addAverageAppliance);
        }

        [When(@"I enter the electrical ""(.*)"" in p/kwh")]
        public void WhenIEnterTheElectricalInPKwh(string average_rate)
        {
            compareApplianciesHomePage.enterElectricalAverageRate(average_rate);
        }

        [When(@"I select Add appliance to your list button option")]
        public void WhenISelectAddApplianceToYourListButtonOption()
        {
            compareApplianciesHomePage.selectAddApplianceToYourListButton();
        }
        
        [Then(@"I should get the result display in tablet format on screen with '(.*)','(.*)','(.*)' and '(.*)'")]
        public void ThenIShouldGetTheResultDisplayInTabletFormatOnScreenWithAnd(string daily, string weekly, string monthly, string yearly)
        {
            compareApplianciesHomePage.displayApplianceResult();
        }
        
        [Then(@"I should get the result display message as '(.*)'")]
        public void ThenIShouldGetTheResultDisplayMessageAs(string error_message)
        {
            compareApplianciesHomePage.verifyErrorMessageOnScreen(error_message);
        }

        [AfterScenario]
        public static void closeBrowser()
        {
            driver.Quit();
        }
    }
}
