﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Framework.Settings
{
    class AppConfigKeys
    {
        public const string Browser = "Browser";
        public const string WebSite = "WebSite";
    }
}
